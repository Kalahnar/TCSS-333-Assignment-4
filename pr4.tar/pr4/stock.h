#ifndef STOCK_H
#define STOCK_H

typedef struct stock *Stock;
//i used what we did in lab as an example
Stock createStock(char* symbol, float price);
void destroyStock(Stock sP);
void prints(Stock sP);
char* getSymbol(Stock sptr);
float getPrice(Stock sptr);

#endif



