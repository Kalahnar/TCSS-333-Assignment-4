    #include "client.h"
    #include <stdlib.h>
    #include <stdio.h>
    #include <string.h>

    struct client {
      int id; //int for the id since all the elements are numbers
      char* name; //array of characters for name because letters
      char* phone;//phone is array of chars because of dashes and also it would be too complicated to use int i got an error first couple of times
      char* email; //email array of chars because of @ symbols and .
    };


    // returns the pointer to the list; NULL if list not created
    Client createClient(int id, char* name, char* phone, char* email) {
      // allocate memory for a structure variable containing all
      // list components
      Client cptr = malloc(sizeof(struct client));
      // if allocation was succesfull
      if (cptr != NULL) {
        cptr->id = id;
        cptr->name = malloc(256);  // Allocate memory
         strcpy(cptr->name, name);
         cptr->phone = malloc(256);  // Allocate memory
         strcpy(cptr->phone, phone);
         cptr->email = malloc(256);  // Allocate memory
         strcpy(cptr->email, email);
         
      }
      return cptr;
    }
    //looked at the code we did in labs and used it
    void destroyClient(Client cptr) {
      free(cptr->name);
      free(cptr->phone);
      free(cptr->email);
      free(cptr);
    }
    //simple printing method also from class 
    void printc(Client cptr){
      printf("%d %s %s %s\n", cptr->id, cptr->name, cptr->phone, cptr->email);
    }
    //all getter methods are the same, they just return what they were supposed to get 
    
    //returns client id
    int getId(Client cptr){
      return cptr->id;
    }
    //returns client name
    char* getName(Client cptr){
      return cptr->name;
    }
    //returns client phone
    char* getPhone(Client cptr){
      return cptr->phone;
    }
    //returns client email
    char* getEmail(Client cptr){
      return cptr->email;
    }
