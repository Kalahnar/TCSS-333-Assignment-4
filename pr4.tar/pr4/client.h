#ifndef CLIENT_H
#define CLIENT_H
//i used what we did in lab to write header file for the all the .h files
typedef struct client *Client;

Client createClient(int id, char* name, char* phone, char* email);
void destroyClient(Client cP);
void printc(Client cP);
int getId(Client cP);
char* getName(Client cP);
char* getPhone(Client cP);
char* getEmail(Client cP);

#endif
