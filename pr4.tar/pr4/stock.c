#include "stock.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

struct stock {
  float price;
  char* symbol;
};


// returns the pointer to the list; NULL if list not created
Stock createStock(char* symbol, float price) {
  // allocate memory for a structure variable containing all
  // list components
  Stock sptr = malloc(sizeof(struct stock));
  // if allocation was succesfull
  if (sptr != NULL) {
     sptr->price = price;
     sptr->symbol = malloc(256);
     strcpy(sptr->symbol, symbol);
     
  }
  return sptr;
}

//used destroy as we did in the lab
void destroyStock(Stock sptr) {
  free(sptr->symbol);
  free(sptr);
}

//prints stocks symbol and price
void prints(Stock sptr){
  printf("%s %f\n", sptr->symbol, sptr->price);
}

//returns stock's symbol
char* getSymbol(Stock sptr){
  return sptr->symbol;
}

//returns stock's price
float getPrice(Stock sptr){
  return sptr->price;
}
