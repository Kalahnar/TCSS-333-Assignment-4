/*
 * Author: Luka Gajic kalahnar@uw.edu
 * Project: pr4.c
 * Version: 3.0 had some complications had to delete project 2 times and start over again
 * Worked on: Ubuntu 16.04 LTS Desktop 32-bit
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "listADTgen.h"
#include "client.h"
#include "stock.h"

/*
 *Function to get client from list using id
 *For loop goes through the list of clients and gets them in order
*/
Client getById(ListType listP, int id){
	Client *cptr;
	int i;
	for(i=0; i<size_is(listP); ++i){
		cptr = get(listP, i);
		if(id == getId(*cptr)){
			return *cptr;
		}
	}
}

/*
 *Function to get stock from list using stock symbol
 * For loop goes through the list of stocks related to clients and gets them according to    their position
*/
Stock getStockBySymbol(ListType listP, char* symbol){
	Stock *sptr;
	int i;
	for(i=0; i<size_is(listP); ++i){
		sptr = get(listP, i);
		if(strcmp(symbol, getSymbol(*sptr)) == 0){
			return *sptr;
		}
	}
}

int main(){
	//make 2 lists, one for clients, one for stocks
	ListType l1,l2;
	l1 = create(sizeof(Client));
	l2 = create(sizeof(Stock));

	//file for clients.txt
	FILE *clientFile;
	clientFile = fopen("clients.txt", "r");
	int id;
	char line[256];
	char name[256]; 
	char phone[256];
	char email[256];
	int i=0;
	//while input is available
	while(fgets(line, sizeof(line), clientFile)){
		//first comes id, which is an integer
		id = atoi(line);
		//then take the name, phone and email
		fgets(name, sizeof(name), clientFile);

		fgets(phone, sizeof(phone), clientFile);
		fgets(email, sizeof(email), clientFile);
		//Create client
		Client cptr = createClient(id,name,phone,email);
		//add to the list
		push(l1, &cptr);
	}
	
	//file for stocks.txt
	FILE *stockFile;
	stockFile = fopen("stocks.csv", "r");
	float price;
	char symbol[256];

	i=0;
	fgets(line, sizeof(line), stockFile);
	//take input while it is available
	while(fgets(line, sizeof(line), stockFile)){
		//read a line and separate it by comma
		char *token = strtok(line, ",");
		strcpy(symbol, token);
		token = strtok(NULL, "\n");
		price = atof(token);
		//create stock and add to list
		Stock sptr = createStock(symbol, price);
		push(l2,&sptr);
	}

	//the stock_client.txt file
	FILE *scFile;
	scFile = fopen("stock_client.txt", "r");
	//the output file
	FILE *summaryFile;
	summaryFile = fopen("summary.csv", "w");
	int client_id;
	int num;
	char sym[256];
	int numStocks;
	char *somel;
	float tot;
	//while input is avaiable in stock_client.txt file
	while(fscanf(scFile, "%d", &client_id) != EOF){
		//find client by ID
		Client cP = getById(l1, client_id);
		int nameSize = strlen(getName(cP));
		int phoneSize = strlen(getPhone(cP));
		int emailSize = strlen(getEmail(cP));
		//print the client details to the file
		fprintf(summaryFile, "%d,%.*s,,%.*s,%.*s\n,", getId(cP), nameSize-2, getName(cP), phoneSize-2, getPhone(cP), emailSize-1, getEmail(cP));
		fscanf(scFile, "%d", &num);
		tot = 0;
		//loop through the stcoks of clients
		for(i=0; i<num; ++i){
			fscanf(scFile, "%s", sym);
			fscanf(scFile, "%d", &numStocks);
			//find stock by its symbol
			Stock sP = getStockBySymbol(l2, sym);
			//write information of stock to file
			fprintf(summaryFile, "%s,%d,%f,\n,", sym, numStocks, getPrice(sP));
			//also add the stocks value to total value
			tot = tot + numStocks*getPrice(sP);
		}
		//print total value of stocks
		fprintf(summaryFile, "%f,,,\n", tot);
	}
}

