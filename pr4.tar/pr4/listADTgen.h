#ifndef LISTADT_H
#define LISTADT_H

typedef struct list_type *ListType;
//similar as what we did in labs
ListType create(int elSize);
void destroy(ListType listP);
void make_empty(ListType listP);
int is_empty(ListType listP);
int is_full(ListType listP);
int size_is(ListType listP);
void push(ListType listP, void *item);
void delete(ListType listP, void* item);
void printl(ListType listP, void (*printItem) (void *item));
void* get(ListType listP,int index);

#endif



